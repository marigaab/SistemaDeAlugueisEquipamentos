/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author hidde
 */
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.ERROR_MESSAGE;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Modelo.ModeloCliente;

public class CadastroClienteDao {
	
    private ConexaoBanco conexao;

    public CadastroClienteDao(){
        this.conexao = new ConexaoBanco();
    }
    
    public void inserir (ModeloCliente cadastro){
        String sql = "INSERT INTO clientes (nome, cpf, cnpj, telefone, celular, endereco, numero, bairro, cep, UF, cidade, complemento) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try {
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1,  cadastro.getNomeCliente());
                sentenca.setString(2,  cadastro.getCpfCliente());
                sentenca.setString(3,  cadastro.getCnpjCliente());
                sentenca.setString(4,  cadastro.getTelefoneCliente());
                sentenca.setString(5,  cadastro.getCelularCliente());
                sentenca.setString(6,  cadastro.getEnderecoCliente());
                if (cadastro.getNumeroCliente() != null) {
                    sentenca.setInt(7, cadastro.getNumeroCliente());
                } else {
                    sentenca.setNull(7, java.sql.Types.INTEGER);
                }
                sentenca.setString(8,  cadastro.getBairroCliente());
                sentenca.setString(9,  cadastro.getCepCliente());
                sentenca.setString(10, cadastro.getUfCliente());
                sentenca.setString(11, cadastro.getCidadeCliente());
                sentenca.setString(12, cadastro.getComplementoCliente());
              
                sentenca.execute();
                sentenca.close();
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void alterar (ModeloCliente cadastro){
        String sql = "UPDATE clientes "+ 
                     "SET nome = ?, cpf = ?, cnpj = ?, telefone = ?, celular = ?, " +
                     "endereco = ?, numero = ?, bairro = ?, cep = ?, UF = ?, cidade = ?, complemento = ?";
        
        try {
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1,  cadastro.getNomeCliente());
                sentenca.setString(2,  cadastro.getCpfCliente());
                sentenca.setString(3,  cadastro.getCnpjCliente());
                sentenca.setString(4,  cadastro.getTelefoneCliente());
                sentenca.setString(5,  cadastro.getCelularCliente());
                sentenca.setString(6,  cadastro.getEnderecoCliente());
                sentenca.setInt   (7,     cadastro.getNumeroCliente());
                sentenca.setString(8,  cadastro.getBairroCliente());
                sentenca.setString(9,  cadastro.getCepCliente());
                sentenca.setString(10, cadastro.getUfCliente());
                sentenca.setString(11, cadastro.getCidadeCliente());
                sentenca.setString(12, cadastro.getComplementoCliente());
           
                sentenca.execute();
                sentenca.close();
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public ArrayList<ModeloCliente> consultar (){
        
        ArrayList<ModeloCliente> ListaClientes = new ArrayList<ModeloCliente>();
        String sql = "SELECT c.id, c.nome, c.cpf, c.cnpj, c.telefone, c.celular, c.status, " +
                     "c.endereco, c.numero, c.bairro, c.cep, c.UF, c.cidade, c.complemento " +
                     "FROM clientes c " +
                     "ORDER BY c.nome";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloCliente cadastro = new ModeloCliente();
                    cadastro.setIdCliente               (resultadoSentenca.getInt          ("id"));
                    cadastro.setNomeCliente             (resultadoSentenca.getString      ("nome"));
                    cadastro.setCpfCliente		(resultadoSentenca.getString      ("cpf"));
                    cadastro.setCnpjCliente		(resultadoSentenca.getString      ("cnpj"));
                    cadastro.setTelefoneCliente		(resultadoSentenca.getString   ("telefone"));
                    cadastro.setCelularCliente		(resultadoSentenca.getString   ("celular"));
                    cadastro.setStatusCliente		(resultadoSentenca.getString    ("status"));
                    cadastro.setEnderecoCliente		(resultadoSentenca.getString   ("endereco"));
                    cadastro.setNumeroCliente		(resultadoSentenca.getInt       ("numero"));
                    cadastro.setBairroCliente		(resultadoSentenca.getString    ("bairro"));
                    cadastro.setCepCliente		(resultadoSentenca.getString      ("cep"));
                    cadastro.setUfCliente		(resultadoSentenca.getString       ("UF"));
                    cadastro.setCidadeCliente		(resultadoSentenca.getString    ("cidade"));
                    cadastro.setComplementoCliente	(resultadoSentenca.getString("complemento"));
                    
                    ListaClientes.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return ListaClientes;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }

    public ArrayList<ModeloCliente> consultar (String str){
        
        ArrayList<ModeloCliente> ListaClientes = new ArrayList<ModeloCliente>();
       String sql = "SELECT c.id, c.nome, c.cpf, c.cnpj, c.telefone, c.celular, c.status, " +
                     "c.endereco, c.numero, c.bairro, c.cep, c.UF, c.cidade, c.complemento " +
                     "FROM clientes c " +
                     "WHERE UPPER (c.nome) LIKE UPPER (?) " +
                     "ORDER BY c.id";
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, "%"+str+"%");
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloCliente cadastro = new ModeloCliente();
                    cadastro.setIdCliente               (resultadoSentenca.getInt          ("id"));
                    cadastro.setNomeCliente             (resultadoSentenca.getString      ("nome"));
                    cadastro.setCpfCliente		(resultadoSentenca.getString      ("cpf"));
                    cadastro.setCnpjCliente		(resultadoSentenca.getString      ("cnpj"));
                    cadastro.setTelefoneCliente		(resultadoSentenca.getString   ("telefone"));
                    cadastro.setCelularCliente		(resultadoSentenca.getString   ("celular"));
                    cadastro.setStatusCliente		(resultadoSentenca.getString    ("status"));
                    cadastro.setEnderecoCliente		(resultadoSentenca.getString   ("endereco"));
                    cadastro.setNumeroCliente		(resultadoSentenca.getInt       ("numero"));
                    cadastro.setBairroCliente		(resultadoSentenca.getString    ("bairro"));
                    cadastro.setCepCliente		(resultadoSentenca.getString      ("cep"));
                    cadastro.setUfCliente		(resultadoSentenca.getString       ("UF"));
                    cadastro.setCidadeCliente		(resultadoSentenca.getString    ("cidade"));
                    cadastro.setComplementoCliente	(resultadoSentenca.getString("complemento"));
                    
                    ListaClientes.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return ListaClientes;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public ArrayList<ModeloCliente> consultar (int id){
        
        ArrayList<ModeloCliente> ListaClientes = new ArrayList<ModeloCliente>();
        String sql = "SELECT c.id, c.nome, c.cpf, c.cnpj, c.telefone, c.celular, c.status, " +
                     "c.endereco, c.numero, c.bairro, c.cep, c.UF, c.cidade, c.complemento " +
                     "FROM clientes c " +
                     "WHERE UPPER (c.id) LIKE UPPER (?) " +
                     "ORDER BY c.id";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, "%"+id+"%");
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloCliente cadastro = new ModeloCliente();
                    cadastro.setIdCliente               (resultadoSentenca.getInt          ("id"));
                    cadastro.setNomeCliente             (resultadoSentenca.getString      ("nome"));
                    cadastro.setCpfCliente		(resultadoSentenca.getString      ("cpf"));
                    cadastro.setCnpjCliente		(resultadoSentenca.getString      ("cnpj"));
                    cadastro.setTelefoneCliente		(resultadoSentenca.getString   ("telefone"));
                    cadastro.setCelularCliente		(resultadoSentenca.getString   ("celular"));
                    cadastro.setStatusCliente		(resultadoSentenca.getString    ("status"));
                    cadastro.setEnderecoCliente		(resultadoSentenca.getString   ("endereco"));
                    cadastro.setNumeroCliente		(resultadoSentenca.getInt       ("numero"));
                    cadastro.setBairroCliente		(resultadoSentenca.getString    ("bairro"));
                    cadastro.setCepCliente		(resultadoSentenca.getString      ("cep"));
                    cadastro.setUfCliente		(resultadoSentenca.getString       ("UF"));
                    cadastro.setCidadeCliente		(resultadoSentenca.getString    ("cidade"));
                    cadastro.setComplementoCliente	(resultadoSentenca.getString("complemento"));
                    
                    ListaClientes.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return ListaClientes;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
   
    public String consultarId(int id) {
        String sql = "SELECT c.nome FROM clientes c WHERE c.id = ? ORDER BY c.id";
        String nomeCliente = null;

        try {
            if (this.conexao.conectar()) {
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                sentenca.setInt(1, id);

                ResultSet resultadoSentenca = sentenca.executeQuery();

                if (resultadoSentenca.next()) {
                    nomeCliente = resultadoSentenca.getString("nome");
                }
                
                sentenca.close();
                return nomeCliente;
            }
        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao consultar cliente pelo ID: " + ex.getMessage(), ex);
        }
        
        return null;
    }

   public ArrayList<ModeloCliente> dashboard() {

    ArrayList<ModeloCliente> listarDashBoard = new ArrayList<>();
    String sql = "SELECT COUNT(*) AS total, COUNT(*) * 2 AS soma FROM clientes";

    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);

            // Recebe o resultado da consulta
            ResultSet resultadoSentenca = sentenca.executeQuery();

            while (resultadoSentenca.next()) {
                // Cria o objeto ModeloCliente e preenche com os valores do resultado
                ModeloCliente cadastro = new ModeloCliente();
                
                cadastro.setTotalCadastrosClientes(resultadoSentenca.getInt("total")); 
                cadastro.setSomaCadastrosClientes(resultadoSentenca.getInt("soma"));
                
                listarDashBoard.add(cadastro);
            }

            // Fecha os recursos
            resultadoSentenca.close();
            sentenca.close();
            this.conexao.getConnection().close();
        }

        return listarDashBoard;
    } catch (SQLException ex) {
        throw new RuntimeException(ex);
    }
}
   
   public ModeloCliente dashboardClientes() {
    ModeloCliente cliente = new ModeloCliente();
    String sql = """
        SELECT 
            (SELECT COUNT(*) FROM clientes WHERE WEEK(data_registro) = WEEK(CURDATE()) AND YEAR(data_registro) = YEAR(CURDATE())) AS semanal,
            (SELECT COUNT(*) FROM clientes WHERE MONTH(data_registro) = MONTH(CURDATE()) AND YEAR(data_registro) = YEAR(CURDATE())) AS mensal,
            (SELECT COUNT(*) FROM clientes WHERE YEAR(data_registro) = YEAR(CURDATE())) AS anual;
    """;

    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
            ResultSet resultado = sentenca.executeQuery();

            if (resultado.next()) {
                cliente.setTotalClientesSemanal(resultado.getInt("semanal"));
                cliente.setTotalClientesMensal(resultado.getInt("mensal"));
                cliente.setTotalClientesAnual(resultado.getInt("anual"));
            }

            resultado.close();
            sentenca.close();
            this.conexao.getConnection().close();
        }
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao carregar dados do dashboard: " + ex.getMessage());
    }

    return cliente;
}


}

