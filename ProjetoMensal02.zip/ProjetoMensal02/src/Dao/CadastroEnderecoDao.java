/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.ERROR_MESSAGE;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Modelo.ModeloEnderecos;

/**
 *
 * @author maria
 */
public class CadastroEnderecoDao {
	
    private ConexaoBanco conexao;

    public CadastroEnderecoDao(){
        this.conexao = new ConexaoBanco();
    }
    
    public void inserir (ModeloEnderecos cadastro){
        String sql = "INSERT INTO endereco ( cep,bairro,logradouro,cidade,numero,complemento,UF) VALUES(?, ?, ?, ?, ?, ?, ?)";
        
        try {
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1,  cadastro.getCepEndereco());
                sentenca.setString(2,  cadastro.getBairroEndereco());
                sentenca.setString(3,  cadastro.getLogradouroEndereco());
                sentenca.setString(4,  cadastro.getCidadeEndereco());
                sentenca.setString(5,  cadastro.getNumeroEndereco());
                sentenca.setString(6,  cadastro.getComplementoEndereco());
                sentenca.setString(7, cadastro.getUfEndereco());
                sentenca.execute();
                sentenca.close();
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
  /*  public void alterar (ModeloEnderecos cadastro){
        String sql = "UPDATE endereco  "+ 
                     "SET cep = ?, bairro = ?, logradouro = ?, cidade = ?, numero = ? , complemento = ?, UF = ?";
        
        try {
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1,  cadastro.getCepEndereco());
                sentenca.setString(2,  cadastro.getBairroEndereco());
                sentenca.setString(3,  cadastro.getLogradouroEndereco());
                sentenca.setString(4,  cadastro.getCidadeEndereco());
                sentenca.setString(5,  cadastro.getNumeroEndereco());
                sentenca.setString(6,  cadastro.getComplementoEndereco());
                sentenca.setString(7, cadastro.getUfEndereco());
                sentenca.execute();
                sentenca.close();
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    } */
    
   /* public void alterar(ModeloEnderecos cadastro) {
    String sql = "UPDATE endereco " + 
                 "SET cep = ?, bairro = ?, logradouro = ?, cidade = ?, numero = ?, complemento = ?, UF = ? " +
                 "WHERE id = ?"; // Adicione a cláusula WHERE para identificar o registro

    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);

            sentenca.setString(1, cadastro.getCepEndereco());
            sentenca.setString(2, cadastro.getBairroEndereco());
            sentenca.setString(3, cadastro.getLogradouroEndereco());
            sentenca.setString(4, cadastro.getCidadeEndereco());
            sentenca.setString(5, cadastro.getNumeroEndereco());
            sentenca.setString(6, cadastro.getComplementoEndereco());
            sentenca.setString(7, cadastro.getUfEndereco());
            sentenca.setInt(8, cadastro.getIdEndereco()); // Supondo que o ID seja armazenado no modelo

            sentenca.execute();
            sentenca.close();
            this.conexao.getConnection().close();
        }
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao alterar endereço: " + ex.getMessage(), ex);
    }
} */
    

    
    public void excluir(String logradouroEndereco) {
        
    String sql = "DELETE FROM endereco WHERE logradouro = ?";

    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);

            sentenca.setString(1, logradouroEndereco);

            sentenca.execute();

            sentenca.close();
            this.conexao.getConnection().close();
        }
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao excluir o endereço: " + logradouroEndereco, ex);
    }
}

    
    public ArrayList<ModeloEnderecos> consultar (){
        
        ArrayList<ModeloEnderecos> ListaEnderecos = new ArrayList<ModeloEnderecos>();
        String sql = "SELECT c.id, c.cep, c.bairro, c.logradouro, c.cidade, c.numero, c.complemento, c.UF " +
                     "FROM endereco c " +
                     "ORDER BY c.logradouro";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloEnderecos cadastro = new ModeloEnderecos();
                    cadastro.setIdEndereco (resultadoSentenca.getInt("id"));
                    cadastro.setCepEndereco               (resultadoSentenca.getString          ("cep"));
                    cadastro.setBairroEndereco            (resultadoSentenca.getString      ("bairro"));
                    cadastro.setLogradouroEndereco		(resultadoSentenca.getString      ("logradouro"));
                    cadastro.setCidadeEndereco		(resultadoSentenca.getString      ("cidade"));
                    cadastro.setNumeroEndereco		(resultadoSentenca.getString   ("numero"));
                    cadastro.setComplementoEndereco		(resultadoSentenca.getString   ("complemento"));
                    cadastro.setUfEndereco		(resultadoSentenca.getString    ("uf"));
                
                    
                    ListaEnderecos.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return ListaEnderecos;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }

    public ArrayList<ModeloEnderecos> consultar (String str){
        
        ArrayList<ModeloEnderecos> ListaEnderecos = new ArrayList<ModeloEnderecos>();
       String sql = "SELECT c.cep, c.bairro, c.logradouro, c.cidade, c.numero, c.complemento, c.UF "  +
                     "FROM endereco c " +
                     "WHERE UPPER (c.logradouro) LIKE UPPER (?) " +
                     "ORDER BY c.id";
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, "%"+str+"%");
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloEnderecos cadastro = new ModeloEnderecos();
                    cadastro.setCepEndereco               (resultadoSentenca.getString          ("cep"));
                    cadastro.setBairroEndereco            (resultadoSentenca.getString      ("bairro"));
                    cadastro.setLogradouroEndereco		(resultadoSentenca.getString      ("logradouro"));
                    cadastro.setCidadeEndereco		(resultadoSentenca.getString      ("cidade"));
                    cadastro.setNumeroEndereco		(resultadoSentenca.getString   ("numero"));
                    cadastro.setComplementoEndereco		(resultadoSentenca.getString   ("complemento"));
                    cadastro.setUfEndereco		(resultadoSentenca.getString    ("uf"));
                    
                    ListaEnderecos.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return ListaEnderecos;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }

    public ModeloEnderecos consultarPorId(int id) {
    String sql = "SELECT c.id, c.cep, c.bairro, c.logradouro, c.cidade, c.numero, c.complemento, c.UF " +
                 "FROM endereco c " +
                 "WHERE c.id = ?";
    
    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
            sentenca.setInt(1, id); // Define o parâmetro ID na query
            ResultSet resultadoSentenca = sentenca.executeQuery();

            if (resultadoSentenca.next()) {
                // Preenche o objeto ModeloEnderecos com os valores do resultado
                ModeloEnderecos endereco = new ModeloEnderecos();
                endereco.setIdEndereco(resultadoSentenca.getInt("id"));
                endereco.setCepEndereco(resultadoSentenca.getString("cep"));
                endereco.setBairroEndereco(resultadoSentenca.getString("bairro"));
                endereco.setLogradouroEndereco(resultadoSentenca.getString("logradouro"));
                endereco.setCidadeEndereco(resultadoSentenca.getString("cidade"));
                endereco.setNumeroEndereco(resultadoSentenca.getString("numero"));
                endereco.setComplementoEndereco(resultadoSentenca.getString("complemento"));
                endereco.setUfEndereco(resultadoSentenca.getString("uf"));

                sentenca.close();
                this.conexao.getConnection().close();
                return endereco; // Retorna o endereço encontrado
            }

            sentenca.close();
            this.conexao.getConnection().close();
        }

        return null; // Retorna null caso nenhum endereço seja encontrado
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao consultar endereço por ID: " + ex.getMessage(), ex);
    }
}

}
    