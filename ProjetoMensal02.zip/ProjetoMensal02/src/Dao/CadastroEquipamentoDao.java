/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author hidde
 */

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Modelo.ModeloEquipamento;

public class CadastroEquipamentoDao {
	
    private ConexaoBanco conexao;

    public CadastroEquipamentoDao(){
        this.conexao = new ConexaoBanco();
    }
    
    public void inserir (ModeloEquipamento cadastro){
        String sql = "INSERT INTO equipamentos (Nome, modelo, marca, tipo, data_entrada, status) VALUES(?, ?, ?, ?, ?, ?)";
        
        try {
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, cadastro.getNomeEquipamento());
                sentenca.setString(2, cadastro.getModeloEquipamento());
                sentenca.setString(3, cadastro.getMarcaEquipamento());
                sentenca.setString(4, cadastro.getTipoEquipamento());
                sentenca.setString(5, cadastro.getEntradaEquipamento());
                sentenca.setString(6, cadastro.getStatusEquipamento());
                sentenca.execute();
                sentenca.close();
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
  public void alterar(ModeloEquipamento cadastro) {
    String sql = "UPDATE equipamentos SET modelo = ?, marca = ?, tipo = ?, data_entrada = ?, status = ?, quantidade = ? WHERE Nome = ?";
    
    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
            
            sentenca.setString(1, cadastro.getModeloEquipamento());
            sentenca.setString(2, cadastro.getMarcaEquipamento());
            sentenca.setString(3, cadastro.getTipoEquipamento());
            sentenca.setString(4, cadastro.getEntradaEquipamento());
            sentenca.setString(5, cadastro.getStatusEquipamento());
            sentenca.setInt(6, cadastro.getQuantidadeEquipamento());
            sentenca.setString(7, cadastro.getNomeEquipamento()); 
            
            sentenca.executeUpdate(); 
            sentenca.close();
            this.conexao.getConnection().close();
        }
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao alterar equipamento: " + ex.getMessage(), ex);
    }
}

   
   public void excluir(String NomeEquipamento) {
        
    String sql = "DELETE FROM equipamentos WHERE Nome = ?";

    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);

            sentenca.setString(1, NomeEquipamento);

            sentenca.execute();

            sentenca.close();
            this.conexao.getConnection().close();
        }
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao excluir o endereço: " + NomeEquipamento, ex);
    }
}

   public ModeloEquipamento consultarPorId(int id) {
        String sql = "SELECT e.id, e.Nome, e.modelo, e.marca, e.tipo, e.data_entrada, e.status, e.quantidade " +
                     "FROM equipamentos e " +
                     "WHERE e.id = ?";

        try {
            if (this.conexao.conectar()) {
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                sentenca.setInt(1, id);
                ResultSet resultadoSentenca = sentenca.executeQuery();

                if (resultadoSentenca.next()) {
                    ModeloEquipamento equipamento = new ModeloEquipamento();
                    equipamento.setIdEquipamento(resultadoSentenca.getInt("id"));
                    equipamento.setNomeEquipamento(resultadoSentenca.getString("Nome"));
                    equipamento.setModeloEquipamento(resultadoSentenca.getString("modelo"));
                    equipamento.setMarcaEquipamento(resultadoSentenca.getString("marca"));
                    equipamento.setTipoEquipamento(resultadoSentenca.getString("tipo"));
                    equipamento.setEntradaEquipamento(resultadoSentenca.getString("data_entrada"));
                    equipamento.setStatusEquipamento(resultadoSentenca.getString("status"));
                    equipamento.setQuantidadeEquipamento(resultadoSentenca.getInt("quantidade"));

                    sentenca.close();
                    this.conexao.getConnection().close();

                    return equipamento; // Retorna o equipamento encontrado
                }

                sentenca.close();
                this.conexao.getConnection().close();
            }

            return null; // Retorna null caso nenhum equipamento seja encontrado
        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao consultar equipamento por ID: " + ex.getMessage(), ex);
        }
    }

public ArrayList<ModeloEquipamento> consultar() {
    ArrayList<ModeloEquipamento> listaEquipamentos = new ArrayList<>();
    String sql = "SELECT e.id, e.Nome, e.modelo, e.marca, e.tipo, e.data_entrada, e.status, e.quantidade " +
                 "FROM equipamentos e " +
                 "ORDER BY e.id";
    
    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
            ResultSet resultadoSentenca = sentenca.executeQuery();
            
            while (resultadoSentenca.next()) {
                ModeloEquipamento cadastro = new ModeloEquipamento();
                cadastro.setIdEquipamento(resultadoSentenca.getInt("id"));
                cadastro.setNomeEquipamento(resultadoSentenca.getString("Nome"));
                cadastro.setModeloEquipamento(resultadoSentenca.getString("modelo"));
                cadastro.setMarcaEquipamento(resultadoSentenca.getString("marca"));
                cadastro.setTipoEquipamento(resultadoSentenca.getString("tipo"));
                cadastro.setEntradaEquipamento(resultadoSentenca.getString("data_entrada"));
                cadastro.setStatusEquipamento(resultadoSentenca.getString("status")); 
                cadastro.setQuantidadeEquipamento(resultadoSentenca.getInt("quantidade")); 
                
                listaEquipamentos.add(cadastro);
            }
            
            sentenca.close();
            this.conexao.getConnection().close();
        }
        
        return listaEquipamentos;
        
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao consultar equipamentos: " + ex.getMessage(), ex);
    }
}

public ArrayList<ModeloEquipamento> consultar(String str) {
    ArrayList<ModeloEquipamento> listaEquipamentos = new ArrayList<>();
    String sql = "SELECT e.id, e.Nome, e.modelo, e.marca, e.tipo, e.data_entrada, e.status, e.quantidade " +
                 "FROM equipamentos e " +
                 "WHERE UPPER(e.Nome) LIKE UPPER(?) " +
                 "ORDER BY e.id";
    
    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
            sentenca.setString(1, "%" + str + "%");
            ResultSet resultadoSentenca = sentenca.executeQuery();
            
            while (resultadoSentenca.next()) {
                ModeloEquipamento cadastro = new ModeloEquipamento();
                cadastro.setIdEquipamento(resultadoSentenca.getInt("id"));
                cadastro.setNomeEquipamento(resultadoSentenca.getString("Nome"));
                cadastro.setModeloEquipamento(resultadoSentenca.getString("modelo"));
                cadastro.setMarcaEquipamento(resultadoSentenca.getString("marca"));
                cadastro.setTipoEquipamento(resultadoSentenca.getString("tipo"));
                cadastro.setEntradaEquipamento(resultadoSentenca.getString("data_entrada"));
                cadastro.setStatusEquipamento(resultadoSentenca.getString("status")); 
                cadastro.setQuantidadeEquipamento(resultadoSentenca.getInt("quantidade")); 
                
                listaEquipamentos.add(cadastro);
            }
            
            sentenca.close();
            this.conexao.getConnection().close();
        }
        
        return listaEquipamentos;
        
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao consultar equipamentos por nome: " + ex.getMessage(), ex);
    }
}
public ModeloEquipamento obterTotaisEquipamentos() {
        String sql = "SELECT " +
                     "SUM(CASE WHEN status = 'disponivel' THEN 1 ELSE 0 END) AS totalDisponiveis, " +
                     "SUM(CASE WHEN status = 'ocupado' THEN 1 ELSE 0 END) AS totalOcupados, " +
                     "SUM(CASE WHEN status = 'troca' THEN 1 ELSE 0 END) AS totalTroca " +
                     "FROM equipamentos";

        ModeloEquipamento dadosEquipamentos = new ModeloEquipamento();

        try {
            if (this.conexao.conectar()) {
                PreparedStatement stmt = this.conexao.getConnection().prepareStatement(sql);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    dadosEquipamentos.setTotalDisponiveis(rs.getInt("totalDisponiveis"));
                    dadosEquipamentos.setTotalOcupados(rs.getInt("totalOcupados"));
                    dadosEquipamentos.setTotalTroca(rs.getInt("totalTroca"));
                }

                rs.close();
                stmt.close();
                this.conexao.getConnection().close();
            }
        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao obter totais de equipamentos: " + ex.getMessage());
        }

        return dadosEquipamentos;
    }
}
