/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author hidde
 */

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Modelo.ModeloMotorista;

public class CadastroMotoristaDao {
	
    private ConexaoBanco conexao;

    public CadastroMotoristaDao(){
        this.conexao = new ConexaoBanco();
    }
    
    public void inserir (ModeloMotorista cadastro){
        String sql = "INSERT INTO motorista (nome, cnh, tipo_cnh, celular) VALUES(?, ?, ?, ?)";
        
        try {
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, cadastro.getNomeMotorista());
                sentenca.setString(2, cadastro.getCnhMotorista());
                sentenca.setString(3, cadastro.getTipoCnhMotorista());
                sentenca.setString(4, cadastro.getCelularMotorista());
                sentenca.execute();
                sentenca.close();
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void alterar (ModeloMotorista cadastro){
        String sql = "UPDATE motorista SET nome = ?, cnh = ?, tipo_cnh = ?, celular = ? WHERE id = ?";
        
        try {
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, cadastro.getNomeMotorista());
                sentenca.setString(2, cadastro.getCnhMotorista());
                sentenca.setString(3, cadastro.getTipoCnhMotorista());
                sentenca.setString(4, cadastro.getCelularMotorista());
                sentenca.setInt   (5, cadastro.getIdMotorista());
                sentenca.execute();
                sentenca.close();
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public ArrayList<ModeloMotorista> consultar (){
        
        ArrayList<ModeloMotorista> listaMotoristas = new ArrayList<ModeloMotorista>();
        String sql = "SELECT m.id, m.nome, m.cnh, m.tipo_cnh, m.celular " +
                     "FROM motorista m " +
                     "ORDER BY m.id";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloMotorista cadastro = new ModeloMotorista();
                    cadastro.setIdMotorista     (resultadoSentenca.getInt       ("id"));
                    cadastro.setNomeMotorista   (resultadoSentenca.getString  ("nome"));
                    cadastro.setCnhMotorista    (resultadoSentenca.getString   ("cnh"));
                    cadastro.setTipoCnhMotorista(resultadoSentenca.getString("tipo_cnh"));
                    cadastro.setCelularMotorista(resultadoSentenca.getString("celular"));
                    
                    listaMotoristas.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return listaMotoristas;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }

    public ArrayList<ModeloMotorista> consultar (String str){
        
        ArrayList<ModeloMotorista> listaMotoristas = new ArrayList<ModeloMotorista>();
        String sql = "SELECT m.id, m.nome, m.cnh, m.tipo_cnh, m.celular " +
                     "FROM motorista m " +
                     "WHERE UPPER (m.nome) LIKE UPPER (?) " +
                     "ORDER BY m.id";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, "%"+str+"%");
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloMotorista cadastro = new ModeloMotorista();
                    cadastro.setIdMotorista     (resultadoSentenca.getInt       ("id"));
                    cadastro.setNomeMotorista   (resultadoSentenca.getString  ("nome"));
                    cadastro.setCnhMotorista    (resultadoSentenca.getString   ("cnh"));
                    cadastro.setTipoCnhMotorista(resultadoSentenca.getString("tipo_cnh"));
                    cadastro.setCelularMotorista(resultadoSentenca.getString("celular"));
                    
                    listaMotoristas.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return listaMotoristas;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
     public ArrayList<ModeloMotorista> dashboard() {

    ArrayList<ModeloMotorista> listarDashBoard = new ArrayList<>();
    String sql = "SELECT COUNT(*) AS total, COUNT(*) * 2 AS soma FROM motorista";

    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);

            // Recebe o resultado da consulta
            ResultSet resultadoSentenca = sentenca.executeQuery();

            while (resultadoSentenca.next()) {
                // Cria o objeto ModeloCliente e preenche com os valores do resultado
                ModeloMotorista cadastro = new ModeloMotorista();
                
                cadastro.setTotalCadastrosMotoristas(resultadoSentenca.getInt("total")); 
                cadastro.setSomaCadastrosMotoristas(resultadoSentenca.getInt("soma"));
                
                listarDashBoard.add(cadastro);
            }

            // Fecha os recursos
            resultadoSentenca.close();
            sentenca.close();
            this.conexao.getConnection().close();
        }

        return listarDashBoard;
    } catch (SQLException ex) {
        throw new RuntimeException(ex);
    }
}
     
     public ModeloMotorista dashboardMotoristas() {
    ModeloMotorista motorista = new ModeloMotorista();

    String sql = """
        SELECT 
            (SELECT COUNT(*) FROM motorista WHERE rota = 'disponivel') AS disponiveis,
            (SELECT COUNT(*) FROM motorista WHERE rota = 'ocupado') AS emRota;
    """;

    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
            ResultSet resultado = sentenca.executeQuery();

            if (resultado.next()) {
                motorista.setTotalMotoristasDisponiveis(resultado.getInt("disponiveis"));
                motorista.setTotalMotoristasEmRota(resultado.getInt("emRota"));
            }

            resultado.close();
            sentenca.close();
            this.conexao.getConnection().close();
        }
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao carregar dados do dashboard: " + ex.getMessage());
    }

    return motorista;
}
     
     public void atualizarStatusMotoristaParaOcupado(int idMotorista) {
    String sql = "UPDATE motorista SET rota = 'ocupado' WHERE id = ?";

    try {
        if (this.conexao.conectar()) {
            PreparedStatement stmt = this.conexao.getConnection().prepareStatement(sql);
            stmt.setInt(1, idMotorista);
            stmt.executeUpdate();
            stmt.close();
            this.conexao.getConnection().close();
        }
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao atualizar status do motorista: " + ex.getMessage());
    }
}



}
