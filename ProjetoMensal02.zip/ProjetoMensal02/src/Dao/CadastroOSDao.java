/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author hidde
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Modelo.ModeloOS;
import Modelo.ModeloEquipamentoOS;
import Modelo.ModeloEquipamento;

public class CadastroOSDao {
    
    private ConexaoBanco conexao;
    
    public CadastroOSDao(){
        this.conexao = new ConexaoBanco();
    }
    
    public void inserir(ModeloOS cadastro){
        String sql = "INSERT INTO ordem_servico (data, valor_aluguel, id_cliente, id_endereco, descricao) "
                   + "VALUES (?, ?, ?, ?, ?)";
    
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, cadastro.getDataOS());
                sentenca.setString(2, cadastro.getValorOS());
                sentenca.setInt   (3, cadastro.getClienteOS());
                sentenca.setInt   (4, cadastro.getEnderecoOS());
                sentenca.setString(5, cadastro.getDescricaoOS());
                sentenca.execute();
                sentenca.close();
                
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void inserirOSEntrada(ModeloOS cadastro){
        String sql = "INSERT INTO ordem_servico (descricao, valor_aluguel, id_endereco, id_cliente, data ) "
                   + "VALUES (?, ?, ?, ?, ?)";
    
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, cadastro.getDescricaoOS());
                sentenca.setString(2, cadastro.getValorOS());
                sentenca.setInt   (3, cadastro.getEnderecoOS());
                sentenca.setInt   (4, cadastro.getClienteOS());
                sentenca.setString(5, cadastro.getDataOS());
                sentenca.execute();
                sentenca.close();
                
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void inserirMasEnderecoNull(ModeloOS cadastro){
        String sql = "INSERT INTO ordem_servico (data, valor_aluguel, id_cliente, descricao) "
                   + "VALUES (?, ?, ?, ?)";
    
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, cadastro.getDataOS());
                sentenca.setString(2, cadastro.getValorOS());
                sentenca.setInt   (3, cadastro.getClienteOS());
                sentenca.setString(4, cadastro.getDescricaoOS());
                sentenca.execute();
                sentenca.close();
                
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public ArrayList<ModeloEquipamento> consultarEquipamentosPorOS(int id){
        
        ArrayList<ModeloEquipamento> listaEquipamentos = new ArrayList<ModeloEquipamento>();
        String sql = "SELECT e.id, e.nome, e.modelo, e.marca, e.tipo " +
                     "FROM equipamentos_selecionados_os eos " +
                     "JOIN equipamentos e ON eos.id_equipamento = e.id " +
                     "WHERE eos.id_ordem_servico = ? " +
                     "ORDER BY e.id";

        try {
            if (this.conexao.conectar()) {
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                sentenca.setInt(1, id);
                ResultSet resultadoSentenca = sentenca.executeQuery();

                while (resultadoSentenca.next()) {
                    ModeloEquipamento equipamento = new ModeloEquipamento();
                    equipamento.setIdEquipamento(resultadoSentenca.getInt("id"));
                    equipamento.setNomeEquipamento(resultadoSentenca.getString("nome"));
                    equipamento.setModeloEquipamento(resultadoSentenca.getString("modelo"));
                    equipamento.setMarcaEquipamento(resultadoSentenca.getString("marca"));
                    equipamento.setTipoEquipamento(resultadoSentenca.getString("tipo"));
                    listaEquipamentos.add(equipamento);
                }

                sentenca.close();
                this.conexao.getConnection().close();
            }

            return listaEquipamentos;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    public void inserirEquipamento(int idOS, int idEquipamento){
        String sql = "INSERT INTO equipamentos_selecionados_os (id_ordem_servico, id_equipamento) VALUES (?, ?)";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setInt(1, idOS);
                sentenca.setInt(2, idEquipamento);
                sentenca.execute();
                sentenca.close();                
                alteraStatusEquipamento(0, idEquipamento);                
                
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void alteraStatusEquipamento(int status, int idEquipamento){
        String sql = "UPDATE equipamentos SET status = ? WHERE id = ?";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setInt(1, status);
                sentenca.setInt(2, idEquipamento);
                sentenca.execute();
                sentenca.close();
                
                this.conexao.getConnection().close();
            }
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void alterar (ModeloOS cadastro){
        String sql = "UPDATE ordem_servico SET descricao = ?, id_motorista = ?, id_veiculo = ? WHERE id = ?";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, cadastro.getDescricaoOS());
                sentenca.setInt   (2, cadastro.getMotoristaOS());
                sentenca.setInt   (3, cadastro.getVeiculoOS());
                sentenca.setInt   (4, cadastro.getIdOS());
                sentenca.execute();
                sentenca.close();
                this.conexao.getConnection().close();
                
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void removerEquipamento(int idOS, int idEquipamento){
        String sql = "DELETE FROM equipamentos_selecionados_os WHERE id_ordem_servico = ? AND id_equipamento = ?";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setInt(1, idOS);
                sentenca.setInt(2, idEquipamento);
                sentenca.execute();
                sentenca.close();
                alteraStatusEquipamento(1, idEquipamento);
                
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public ArrayList<ModeloOS> consultarOS (int id){
        ArrayList<ModeloOS> ListaOS = new ArrayList<ModeloOS>();
        String sql = "SELECT o.id, o.data, o.valor_aluguel, o.id_cliente, o.id_endereco "
                + "o.descricao, o.id_motorista, o.id_veiculo "
                + "WHERE o.id LIKE (?) "
                + "ORDER BY o.id";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, "%"+id+"%");
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloOS cadastro = new ModeloOS();
                    
                    cadastro.setIdOS       (resultadoSentenca.getInt        ("id"));
                    cadastro.setDataOS     (resultadoSentenca.getString   ("data"));
                    cadastro.setValorOS    (resultadoSentenca.getString   ("valor_aluguel"));
                    cadastro.setClineteOS  (resultadoSentenca.getInt    ("id_cliente"));
                    cadastro.setEnderecoOS (resultadoSentenca.getInt   ("id_endereco"));
                    cadastro.setDescricaoOS(resultadoSentenca.getString("descricao"));
                    cadastro.setMotoristaOS(resultadoSentenca.getInt   ("id_motorista"));
                    cadastro.setVeivuloOS  (resultadoSentenca.getInt    ("id_veiuclo"));
                    
                    ListaOS.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return ListaOS;
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public ArrayList<ModeloOS> consultarOS (){
        ArrayList<ModeloOS> ListaOS = new ArrayList<ModeloOS>();
        String sql = "SELECT o.id, o.data, o.valor_aluguel, o.id_cliente, o.id_endereco "
                + "o.descricao, o.id_motorista, o.id_veiculo "
                + "ORDER BY o.id";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloOS cadastro = new ModeloOS();
                    
                    cadastro.setIdOS       (resultadoSentenca.getInt        ("id"));
                    cadastro.setDataOS     (resultadoSentenca.getString   ("data"));
                    cadastro.setValorOS    (resultadoSentenca.getString   ("valor_aluguel"));
                    cadastro.setClineteOS  (resultadoSentenca.getInt    ("id_cliente"));
                    cadastro.setEnderecoOS (resultadoSentenca.getInt   ("id_endereco"));
                    cadastro.setDescricaoOS(resultadoSentenca.getString("descricao"));
                    cadastro.setMotoristaOS(resultadoSentenca.getInt   ("id_motorista"));
                    cadastro.setVeivuloOS  (resultadoSentenca.getInt    ("id_veiculo"));
                    
                    ListaOS.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return ListaOS;
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public ModeloOS consultaId(int id){
        ModeloOS cadastro = null;
        
        String sql = "SELECT o.id, o.data, o.valor_aluguel, o.id_cliente, o.id_endereco, "
                   + "o.descricao, o.id_motorista, o.id_veiculo "
                   + "FROM ordem_servico o "
                   + "WHERE o.id = ?";
        
        try{
         if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
            
            sentenca.setInt(1, id);
            ResultSet resultadoSentenca = sentenca.executeQuery();
            
            if (resultadoSentenca.next()) {
                cadastro = new ModeloOS();
                cadastro.setIdOS       (resultadoSentenca.getInt           ("id"));
                cadastro.setDataOS     (resultadoSentenca.getString      ("data"));
                cadastro.setValorOS    (resultadoSentenca.getString      ("valor_aluguel"));
                cadastro.setClineteOS  (resultadoSentenca.getInt       ("id_cliente"));
                cadastro.setEnderecoOS (resultadoSentenca.getInt      ("id_endereco"));
                cadastro.setDescricaoOS(resultadoSentenca.getString   ("descricao"));
                cadastro.setMotoristaOS(resultadoSentenca.getInt      ("id_motorista"));
                cadastro.setVeivuloOS  (resultadoSentenca.getInt       ("id_veiculo"));
            }
            
            sentenca.close();
            this.conexao.getConnection().close();
            
            }           
        } catch (SQLException ex) {
            throw new RuntimeException("Error ", ex);
        }
        return cadastro;
    }
    
    public ArrayList<ModeloOS> dashboard() {

    ArrayList<ModeloOS> listarDashBoard = new ArrayList<>();
    String sql = "SELECT COUNT(*) AS total, COUNT(*) * 2 AS soma FROM ordem_servico";

    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);

            ResultSet resultadoSentenca = sentenca.executeQuery();

            while (resultadoSentenca.next()) {

                ModeloOS cadastro = new ModeloOS();
                
                cadastro.setTotalOS(resultadoSentenca.getInt("total")); 
                cadastro.setSomaOS(resultadoSentenca.getInt("soma"));
                
                listarDashBoard.add(cadastro);
            }

            resultadoSentenca.close();
            sentenca.close();
            this.conexao.getConnection().close();
        }

        return listarDashBoard;
    } catch (SQLException ex) {
        throw new RuntimeException(ex);
    }
     }
    
    public ArrayList<ModeloOS> obterTotaisOS() {
       String sql = "SELECT " +
                    "SUM(CASE WHEN status = 'concluido' THEN 1 ELSE 0 END) AS totalConcluidas, " +
                    "SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) AS totalPendentes " +
                    "FROM ordem_servico";

       ArrayList<ModeloOS> listarDashBoard = new ArrayList<>();

       try {
           if (this.conexao.conectar()) {
               PreparedStatement stmt = this.conexao.getConnection().prepareStatement(sql);
               ResultSet rs = stmt.executeQuery();

               if (rs.next()) {
                   ModeloOS dashboard = new ModeloOS();
                   dashboard.setTotalConcluidas(rs.getInt("totalConcluidas"));
                   dashboard.setTotalPendentes(rs.getInt("totalPendentes"));

                   listarDashBoard.add(dashboard);
               }

               rs.close();
               stmt.close();
               this.conexao.getConnection().close();
           }
       } catch (SQLException ex) {
           throw new RuntimeException("Erro ao obter totais de OS: " + ex.getMessage());
       }

       return listarDashBoard;
   }

    public ModeloOS obterTotaisAlugueis() {
       String sql = "SELECT " +
                    "SUM(CASE WHEN DATE(data_registro) >= CURDATE() - INTERVAL 7 DAY THEN 1 ELSE 0 END) AS totalSemanal, " +
                    "SUM(CASE WHEN DATE(data_registro) >= CURDATE() - INTERVAL 1 MONTH THEN 1 ELSE 0 END) AS totalMensal, " +
                    "SUM(CASE WHEN YEAR(data_registro) = YEAR(CURDATE()) THEN 1 ELSE 0 END) AS totalAnual " +
                    "FROM ordem_servico";

       ModeloOS totais = new ModeloOS();

       try {
           if (this.conexao.conectar()) {
               PreparedStatement stmt = this.conexao.getConnection().prepareStatement(sql);
               ResultSet rs = stmt.executeQuery();

               if (rs.next()) {
                   totais.setTotalSemanal(rs.getInt("totalSemanal"));
                   totais.setTotalMensal(rs.getInt("totalMensal"));
                   totais.setTotalAnual(rs.getInt("totalAnual"));
               }

               rs.close();
               stmt.close();
               this.conexao.getConnection().close();
           }
       } catch (SQLException ex) {
           throw new RuntimeException("Erro ao obter totais de aluguéis: " + ex.getMessage());
       }

       return totais;
   }

    public ModeloOS obterFaturamento() {
       String sql = "SELECT " +
                    "SUM(CASE WHEN DATE(data_registro) >= CURDATE() - INTERVAL 7 DAY THEN valor_aluguel ELSE 0 END) AS faturamentoSemanal, " +
                    "SUM(CASE WHEN DATE(data_registro) >= CURDATE() - INTERVAL 1 MONTH THEN valor_aluguel ELSE 0 END) AS faturamentoMensal, " +
                    "SUM(CASE WHEN YEAR(data_registro) = YEAR(CURDATE()) THEN valor_aluguel ELSE 0 END) AS faturamentoAnual " +
                    "FROM ordem_servico";

       ModeloOS faturamento = new ModeloOS();

       try {
           if (this.conexao.conectar()) {
               PreparedStatement stmt = this.conexao.getConnection().prepareStatement(sql);
               ResultSet rs = stmt.executeQuery();

               if (rs.next()) {
                   faturamento.setFaturamentoSemanal(rs.getFloat("faturamentoSemanal"));
                   faturamento.setFaturamentoMensal(rs.getFloat("faturamentoMensal"));
                   faturamento.setFaturamentoAnual(rs.getFloat("faturamentoAnual"));
               }

               rs.close();
               stmt.close();
               this.conexao.getConnection().close();
           }
       } catch (SQLException ex) {
           throw new RuntimeException("Erro ao obter faturamento: " + ex.getMessage());
       }

       return faturamento;
   }
    
    public ArrayList<ModeloOS> obterTopEnderecos() {
    ArrayList<ModeloOS> lista = new ArrayList<>();
   String sql = """
   SELECT 
        e.logradouro AS endereco, 
        COUNT(os.id_endereco) AS total
    FROM 
        ordem_servico os
    INNER JOIN 
        endereco e ON os.id_endereco = e.id
    GROUP BY 
        e.logradouro
    ORDER BY 
        total DESC
    LIMIT 3;
                """;

    try {
        if (this.conexao.conectar()) {
            PreparedStatement stmt = this.conexao.getConnection().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            ModeloOS modelo = new ModeloOS();
            int rank = 1;

            while (rs.next()) {
                String endereco = rs.getString("endereco");
                int total = rs.getInt("total");

                // Preenche os campos de acordo com o rank
                if (rank == 1) {
                    modelo.setEndereco1(endereco);
                    modelo.setQtdEndereco1(total);
                } else if (rank == 2) {
                    modelo.setEndereco2(endereco);
                    modelo.setQtdEndereco2(total);
                } else if (rank == 3) {
                    modelo.setEndereco3(endereco);
                    modelo.setQtdEndereco3(total);
                }
                rank++;
            }

            // Adiciona o modelo à lista
            lista.add(modelo);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return lista;
}


    public ArrayList<ModeloOS> consultarOsEntrada() {
    ArrayList<ModeloOS> listaOS = new ArrayList<>();
    String sql = "SELECT id, data, valor_aluguel, id_cliente, id_endereco, descricao " +
                 "FROM ordem_servico " +
                 "ORDER BY id";

    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
            ResultSet resultadoSentenca = sentenca.executeQuery();

            while (resultadoSentenca.next()) {
                ModeloOS cadastro = new ModeloOS();

                // Map the fields from the ResultSet to ModeloOS
                cadastro.setIdOS(resultadoSentenca.getInt("id"));
                cadastro.setDataOS(resultadoSentenca.getString("data")); // Ensure ModeloOS has a setter for date
                cadastro.setValorOS(resultadoSentenca.getString("valor_aluguel"));
                cadastro.setClineteOS(resultadoSentenca.getInt("id_cliente"));
                cadastro.setEnderecoOS(resultadoSentenca.getInt("id_endereco"));
                cadastro.setDescricaoOS(resultadoSentenca.getString("descricao"));

                // Add the object to the list
                listaOS.add(cadastro);
            }

            // Close resources
            sentenca.close();
            this.conexao.getConnection().close();
        }

        return listaOS;
    } catch (SQLException ex) {
        throw new RuntimeException("Erro ao consultar ordem_servico: " + ex.getMessage(), ex);
    }
}

    public ModeloOS consultarOsEntradaById(int id) {
        String sql = "SELECT id, data, valor_aluguel, id_cliente, id_endereco, descricao, id_motorista, id_veiculo " +
                     "FROM ordem_servico " +
                     "WHERE id = ?";

        try {
            if (this.conexao.conectar()) {
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                sentenca.setInt(1, id); // Define o parâmetro ID para a consulta
                ResultSet resultadoSentenca = sentenca.executeQuery();

                if (resultadoSentenca.next()) {
                    // Mapear o registro para um objeto ModeloOS
                    ModeloOS cadastro = new ModeloOS();
                    cadastro.setIdOS       (resultadoSentenca.getInt        ("id"));
                    cadastro.setDataOS     (resultadoSentenca.getString   ("data"));
                    cadastro.setValorOS    (resultadoSentenca.getString   ("valor_aluguel"));
                    cadastro.setClineteOS  (resultadoSentenca.getInt    ("id_cliente"));
                    cadastro.setEnderecoOS (resultadoSentenca.getInt   ("id_endereco"));
                    cadastro.setDescricaoOS(resultadoSentenca.getString("descricao"));
                    cadastro.setMotoristaOS(resultadoSentenca.getInt   ("id_motorista"));
                    cadastro.setVeivuloOS  (resultadoSentenca.getInt    ("id_veiculo"));

                    sentenca.close();
                    this.conexao.getConnection().close();

                    return cadastro; // Retorna o objeto encontrado
                }

                sentenca.close();
                this.conexao.getConnection().close();
            }

            return null; // Retorna null caso nenhum registro seja encontrado
        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao consultar ordem_servico por ID: " + ex.getMessage(), ex);
        }
    }

}
