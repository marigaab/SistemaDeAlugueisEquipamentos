/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author hidde
 */

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Modelo.ModeloVeiculo;

public class CadastroVeiculoDao {
	
    private ConexaoBanco conexao;

    public CadastroVeiculoDao(){
        this.conexao = new ConexaoBanco();
    }
    
    public void inserir (ModeloVeiculo cadastro){
        String sql = "INSERT INTO veiculos (nome, ano, marca, placa, n_chassis, n_patrimonio, Observacao) VALUES(?, ?, ?, ?, ?, ?, ?)";
        
        try {
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, cadastro.getNomeVeiculo());
                sentenca.setInt   (2,    cadastro.getAnoVeiculo());
                sentenca.setString(3, cadastro.getMarcaVeiculo());
                sentenca.setString(4, cadastro.getPlacaVeiculo());
                sentenca.setString(5, cadastro.getChassiVeiculo());
                sentenca.setString(6, cadastro.getPatrimonioVeiculo());
                sentenca.setString(7, cadastro.getObservacaoVeiculo());
                sentenca.execute();
                sentenca.close();
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public void alterar (ModeloVeiculo cadastro){
        String sql = "UPDATE veiculos SET nome = ?, ano = ?, marca = ?, placa = ?, n_chassis = ?, n_patrimonio = ?, Observacao = ? WHERE id_Veiculos = ?";
        
        try {
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, cadastro.getNomeVeiculo());
                sentenca.setInt   (2,    cadastro.getAnoVeiculo());
                sentenca.setString(3, cadastro.getMarcaVeiculo());
                sentenca.setString(4, cadastro.getPlacaVeiculo());
                sentenca.setString(5, cadastro.getChassiVeiculo());
                sentenca.setString(6, cadastro.getPatrimonioVeiculo());
                sentenca.setString(7, cadastro.getObservacaoVeiculo());
                sentenca.setInt   (8, cadastro.getIdVeiculo());
                sentenca.execute();
                sentenca.close();
                this.conexao.getConnection().close();
            }
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
    public ArrayList<ModeloVeiculo> consultar (){
        
        ArrayList<ModeloVeiculo> listaVeiculo = new ArrayList<ModeloVeiculo>();
        String sql = "SELECT v.id_veiculos, v.nome, v.ano, v.marca, v.placa, v.n_chassis, v.n_patrimonio, v.Observacao " +
                     "FROM veiculos v " +
                     "ORDER BY v.id_veiculos";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloVeiculo cadastro = new ModeloVeiculo();
                    cadastro.setIdVeiculo        (resultadoSentenca.getInt          ("id_veiculos"));
                    cadastro.setNomeVeiculo      (resultadoSentenca.getString      ("nome"));
                    cadastro.setAnoVeiculo       (resultadoSentenca.getInt         ("ano"));
                    cadastro.setMarcaVeiculo     (resultadoSentenca.getString     ("marca"));
                    cadastro.setPlacaVeiculo     (resultadoSentenca.getString     ("placa"));
                    cadastro.setChassiVeiculo    (resultadoSentenca.getString    ("n_chassis"));
                    cadastro.setPatrimonioVeiculo(resultadoSentenca.getString ("n_patrimonio"));
                    cadastro.setObservacaoVeiculo(resultadoSentenca.getString ("Observacao"));
                    
                    listaVeiculo.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return listaVeiculo;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }

    public ArrayList<ModeloVeiculo> consultar (String str){
        
        ArrayList<ModeloVeiculo> listaVeiculo = new ArrayList<ModeloVeiculo>();
        String sql = "SELECT v.id_veiculos, v.nome, v.ano, v.marca, v.placa, v.n_chassis, v.n_patrimonio, v.Observacao " +
                     "FROM veiculos v " +
                     "WHERE UPPER (v.nome) LIKE UPPER (?)" +
                     "ORDER BY v.id_veiculos";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                sentenca.setString(1, "%"+str+"%");
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloVeiculo cadastro = new ModeloVeiculo();
                    cadastro.setIdVeiculo        (resultadoSentenca.getInt          ("id_veiculos"));
                    cadastro.setNomeVeiculo      (resultadoSentenca.getString      ("nome"));
                    cadastro.setAnoVeiculo       (resultadoSentenca.getInt         ("ano"));
                    cadastro.setMarcaVeiculo     (resultadoSentenca.getString     ("marca"));
                    cadastro.setPlacaVeiculo     (resultadoSentenca.getString     ("placa"));
                    cadastro.setChassiVeiculo    (resultadoSentenca.getString    ("n_chassis"));
                    cadastro.setPatrimonioVeiculo(resultadoSentenca.getString ("n_patrimonio"));
                    cadastro.setObservacaoVeiculo(resultadoSentenca.getString ("Observacao"));
                    
                    listaVeiculo.add(cadastro);
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return listaVeiculo;
            
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
     public ArrayList<ModeloVeiculo> dashboard() {

    ArrayList<ModeloVeiculo> listarDashBoard = new ArrayList<>();
    String sql = "SELECT COUNT(*) AS total, COUNT(*) * 2 AS soma FROM veiculos";

    try {
        if (this.conexao.conectar()) {
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);

            // Recebe o resultado da consulta
            ResultSet resultadoSentenca = sentenca.executeQuery();

            while (resultadoSentenca.next()) {
                // Cria o objeto ModeloCliente e preenche com os valores do resultado
                ModeloVeiculo cadastro = new ModeloVeiculo();
                
                cadastro.setTotalCadastrosVeiculos(resultadoSentenca.getInt("total")); 
                cadastro.setSomaCadastrosVeiculos(resultadoSentenca.getInt("soma"));
                
                listarDashBoard.add(cadastro);
            }

            resultadoSentenca.close();
            sentenca.close();
            this.conexao.getConnection().close();
        }

        return listarDashBoard;
    } catch (SQLException ex) {
        throw new RuntimeException(ex);
    }
}
}
