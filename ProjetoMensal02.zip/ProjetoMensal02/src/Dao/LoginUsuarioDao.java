/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Connection;
import Modelo.ModeloLoginUsuario;
        
/**
 *
 * @author maria
 */
public class LoginUsuarioDao {
    private ConexaoBanco conexao;
    
    public LoginUsuarioDao () 
    {
        this.conexao = new ConexaoBanco ();
    }
    
  
  public void inserir(ModeloLoginUsuario cadastro) {
    String sql = "INSERT INTO login (id, nome, email, senha) VALUES (?, ?, ?, ?)";
    
    try {
        if (this.conexao.conectar()) {
            // prepara a consulta SQL
            PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
            
            sentenca.setInt(1, cadastro.getIdCadUser());
            sentenca.setString(2, cadastro.getNome());
            sentenca.setString(3, cadastro.getEmail());
            sentenca.setString(4, cadastro.getSenha());
            
           
            sentenca.execute();
            sentenca.close();
            this.conexao.getConnection().close();
        }
    } catch (SQLException ex) {
        throw new RuntimeException(ex);
    }
}
 
public ModeloLoginUsuario validarLogin(String nome, String senha) throws Exception {
    String sql = "SELECT * FROM login WHERE nome = ? AND senha = ?";
    Connection conn = null;  // Declare a conexão

    ConexaoBanco conexaoBanco = new ConexaoBanco(); // Instância da classe de conexão
    boolean isConnected = conexaoBanco.conectar(); // Verifica se a conexão foi bem-sucedida

    if (!isConnected) {
        throw new Exception("Falha ao conectar ao banco de dados."); // Lança exceção se não conectar
    }

    conn = conexaoBanco.getConnection(); 

    try {
        
        PreparedStatement stmt = conn.prepareStatement(sql);

        
        stmt.setString(1, nome);
        stmt.setString(2, senha);

       
        ResultSet rs = stmt.executeQuery();

        // Verifica se encontrou um usuário com as credenciais fornecidas
        if (rs.next()) {
            // Cria um objeto  com os dados do usuário
            ModeloLoginUsuario usuario = new ModeloLoginUsuario();
            usuario.setIdCadUser(rs.getInt("id"));
            usuario.setNome(rs.getString("nome"));
            usuario.setSenha(rs.getString("senha"));

            return usuario;  // Login válido
        } else {
            return null;  // Login inválido
        }
    } catch (SQLException e) {
        throw new Exception("Erro ao validar login: " + e.getMessage());
    } finally {
        // Fecha a conexão se ela foi aberta
        if (conn != null) {
            conn.close();
        }
    }
}




}
