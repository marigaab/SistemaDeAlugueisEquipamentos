/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author hidde
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Modelo.ModeloTipoEquipamentos;

public class TipoEquipamentoDao {
    
    private ConexaoBanco conexao;
    
    public TipoEquipamentoDao(){
        this.conexao = new ConexaoBanco();
    }
    
    public ArrayList<ModeloTipoEquipamentos> consultar(){
        
        ArrayList<ModeloTipoEquipamentos> listaTipoEquipamentos = new ArrayList<ModeloTipoEquipamentos>();
        String sql = "SELECT id_tipo, nome_tipo FROM tipo_equipamento ORDER BY nome_tipo";
        
        try{
            if(this.conexao.conectar()){
                PreparedStatement sentenca = this.conexao.getConnection().prepareStatement(sql);
                
                ResultSet resultadoSentenca = sentenca.executeQuery();
                
                while(resultadoSentenca.next()){
                    ModeloTipoEquipamentos TipoEquipamento = new ModeloTipoEquipamentos();
                    TipoEquipamento.setIdTipoEquipamento(resultadoSentenca.getInt("id_tipo"));
                    TipoEquipamento.setNomeTipoEquipamento(resultadoSentenca.getString("nome_tipo"));
                    
                    listaTipoEquipamentos.add(TipoEquipamento);                   
                }
                
                sentenca.close();
                this.conexao.getConnection().close();
            }
            
            return listaTipoEquipamentos;
        }catch(SQLException ex){
            throw new RuntimeException(ex);
        }
    }
    
}
