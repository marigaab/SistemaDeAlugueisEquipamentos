/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author hidde
 */
public class ModeloCliente {
    private int idCliente;
    private String nomeCliente;
    private String cpfCliente;
    private String cnpjCliente;
    private String telefoneCliente;
    private String celularCliente;
    private String statusCliente;
    private String enderecoCliente;
    private Integer numeroCliente;
    private String bairroCliente;
    private String cepCliente;
    private String ufCliente;
    private String cidadeCliente;
    private String complementoCliente;
    private int numCadastrosClientes;
    private int somaCadastrosClientes;
    private int totalClientesSemanal;
    private int totalClientesMensal;
    private int totalClientesAnual;

    
    //construtores
    
    public ModeloCliente(){
    }
    
    //construtor para quando não se tem um id, ou seja, está criando um cliente novo
    public ModeloCliente (String nomeCliente, String cpfCliente, String cnpjCliente, String telefoneCliente, String celularCliente, String statusCliente,
                          String enderecoCliente, int numeroCliente, String bairroCliente, String cepCliente, String ufCliente, String cidadeCliente, String complementoCliente){
        this.nomeCliente = nomeCliente;
        this.cpfCliente = cpfCliente;
        this.cnpjCliente = cnpjCliente;
        this.telefoneCliente = telefoneCliente;
        this.celularCliente = celularCliente;
        this.statusCliente = statusCliente;
        this.enderecoCliente = enderecoCliente;
        this.numeroCliente = numeroCliente;
        this.bairroCliente = bairroCliente;
        this.cepCliente = cepCliente;
        this.ufCliente = ufCliente;
        this.cidadeCliente = cidadeCliente;
        this.complementoCliente = complementoCliente;
        
    }
    
    //construtor para quando já se tem um id e necessita modificar-lo
    public ModeloCliente(int idCliente, String nomeCliente, String cpfCliente, String cnpjCliente, String telefoneCliente, String celularCliente, String statusCliente,
                          String enderecoCliente, int numeroCliente, String bairroCliente, String cepCliente, String ufCliente, String cidadeCliente, String complementoCliente){
        this.idCliente = idCliente;
        this.nomeCliente = nomeCliente;
        this.cpfCliente = cpfCliente;
        this.cnpjCliente = cnpjCliente;
        this.telefoneCliente = telefoneCliente;
        this.celularCliente = celularCliente;
        this.statusCliente = statusCliente;
        this.enderecoCliente = enderecoCliente;
        this.numeroCliente = numeroCliente;
        this.bairroCliente = bairroCliente;
        this.cepCliente = cepCliente;
        this.ufCliente = ufCliente;
        this.cidadeCliente = cidadeCliente;
        this.complementoCliente = complementoCliente;   
    }
    
    public ModeloCliente  (int numCadastrosClientes, int somaCadastrosClientes, int totalClientesSemanal, int totalClientesMensal, int totalClientesAnual) {
        this.numCadastrosClientes = numCadastrosClientes;
        this.somaCadastrosClientes = somaCadastrosClientes;
        this.totalClientesSemanal = totalClientesSemanal;
        this.totalClientesMensal = totalClientesMensal;
        this.totalClientesAnual = totalClientesAnual;

  
    } 
    
    //metodos get
    public int getIdCliente(){
        return idCliente;
    }
    
    public String getNomeCliente(){
        return nomeCliente;
    }
    
    public String getCpfCliente(){
        return cpfCliente;
    }
    
    public String getCnpjCliente(){
        return cnpjCliente;
    }
    
    public String getTelefoneCliente(){
        return telefoneCliente;
    }

    public String getCelularCliente(){
        return celularCliente;
    }

    public String getStatusCliente(){
        return statusCliente;
    }
    
    public String getEnderecoCliente(){
        return enderecoCliente;
    }
    
    public Integer getNumeroCliente(){
        return numeroCliente;
    }
    
    public String getBairroCliente(){
        return bairroCliente;
    }
  
    public String getCepCliente(){
        return cepCliente;
    }
    
    public String getUfCliente(){
        return ufCliente;
    }
    
    public String getCidadeCliente(){
        return cidadeCliente;
    }
    
    public String getComplementoCliente(){
        return complementoCliente;
    }
    
    //metodos set
    public void setIdCliente(int idCliente){
        this.idCliente = idCliente;
    }
    
    public void setNomeCliente(String nomeCliente){
        this.nomeCliente = nomeCliente;
    }
    
    public void setCpfCliente(String cpfCliente){
        this.cpfCliente = cpfCliente;
    }

    public void setCnpjCliente(String cnpjCliente){
        this.cnpjCliente = cnpjCliente;
    }
    
    public void setTelefoneCliente(String telefoneCliente){
        this.telefoneCliente = telefoneCliente;
    }
    
    public void setCelularCliente(String celularCliente){
        this.celularCliente = celularCliente;
    }
    
    public void setStatusCliente(String statusCliente){
        this.statusCliente = statusCliente;
    }
    
    public void setEnderecoCliente(String enderecoCliente){
        this.enderecoCliente = enderecoCliente;
    }
    
    public void setNumeroCliente(Integer numeroCliente){
        this.numeroCliente = numeroCliente;
    }
    
    public void setBairroCliente(String bairroCliente){
        this.bairroCliente = bairroCliente;
    }
    
    public void setCepCliente(String cepCliente){
        this.cepCliente = cepCliente;
    }
    
    public void setUfCliente(String ufCliente){
        this.ufCliente = ufCliente;
    }
    
    public void setCidadeCliente(String cidadeCliente){
        this.cidadeCliente = cidadeCliente;
    }
    
    public void setComplementoCliente(String complementoCliente){
        this.complementoCliente = complementoCliente;
    }
     public int getTotalCadastrosClientes() {
        return numCadastrosClientes;
    }

    public void setTotalCadastrosClientes(int numCadastrosClientes) {
        this.numCadastrosClientes = numCadastrosClientes;
    }

    public int getSomaCadastrosClientes() {
        return somaCadastrosClientes;
    }

    public void setSomaCadastrosClientes(int somaCadastrosClientes) {
    this.somaCadastrosClientes = somaCadastrosClientes;
}
 
     public int getTotalClientesSemanal() {
        return totalClientesSemanal;
    }

    public void setTotalClientesSemanal(int totalClientesSemanal) {
        this.totalClientesSemanal = totalClientesSemanal;
    }

    public int getTotalClientesMensal() {
        return totalClientesMensal;
    }

    public void setTotalClientesMensal(int totalClientesMensal) {
        this.totalClientesMensal = totalClientesMensal;
    }

    public int getTotalClientesAnual() {
        return totalClientesAnual;
    }

    public void setTotalClientesAnual(int totalClientesAnual) {
        this.totalClientesAnual = totalClientesAnual;
    }
}
