/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author hidde
 */
public class ModeloEnderecos {
    private int idEndereco;
    private String logradouroEndereco;
    private String numeroEndereco;
    private String complementoEndereco;
    private String bairroEndereco;
    private String cidadeEndereco;
    private String ufEndereco;
    private String cepEndereco;
    
    //construtores
    
    public ModeloEnderecos(){
    }
    
    //construtor para quando não se tem um id, ou seja, está criando uma entrada novo
    public ModeloEnderecos (String logradouroEndereco, String numeroEndereco, String complementoEndereco, String bairroEndereco, String cidadeEndereco, String ufEndereco, String cepEndereco){
        this.logradouroEndereco = logradouroEndereco;
        this.numeroEndereco = numeroEndereco;
        this.complementoEndereco = complementoEndereco;
        this.bairroEndereco = bairroEndereco;
        this.cidadeEndereco = cidadeEndereco;
        this.cepEndereco = cepEndereco;
    }
    
    //construtor para quando já se tem um id e necessita modificar-lo
    public ModeloEnderecos(int idEndereco, String logradouroEndereco, String numeroEndereco, String complementoEndereco, String bairroEndereco, String cidadeEndereco, String ufEndereco, String cepEndereco){
        this.idEndereco = idEndereco;
        this.logradouroEndereco = logradouroEndereco;
        this.numeroEndereco = numeroEndereco;
        this.complementoEndereco = complementoEndereco;
        this.bairroEndereco = bairroEndereco;
        this.cidadeEndereco = cidadeEndereco;
        this.cepEndereco = cepEndereco;
    }
    
    //metodos get
    public int getIdEndereco(){
        return idEndereco;
    }
    
    public String getLogradouroEndereco(){
        return logradouroEndereco;
    }
    
    public String getNumeroEndereco(){
        return numeroEndereco;
    }
    
    public String getComplementoEndereco(){
        return complementoEndereco;
    }
    
    public String getBairroEndereco(){
        return bairroEndereco;
    }

    public String getCidadeEndereco(){
        return cidadeEndereco;
    }

    public String getUfEndereco(){
        return ufEndereco;
    }
    
    public String getCepEndereco(){
        return cepEndereco;
    }
    
    //metodos set
    public void setIdEndereco(int idEndereco){
        this.idEndereco = idEndereco;
    }
    
    public void setLogradouroEndereco(String logradouroEndereco){
        this.logradouroEndereco = logradouroEndereco;
    }
    
    public void setNumeroEndereco(String numeroEndereco){
        this.numeroEndereco = numeroEndereco;
    }

    public void setComplementoEndereco(String complementoEndereco){
        this.complementoEndereco = complementoEndereco;
    }
    
    public void setBairroEndereco(String bairroEndereco){
        this.bairroEndereco = bairroEndereco;
    }
    
    public void setCidadeEndereco(String cidadeEndereco){
        this.cidadeEndereco = cidadeEndereco;
    }
    
    public void setUfEndereco(String ufEndereco){
        this.ufEndereco = ufEndereco;
    }
    
    public void setCepEndereco(String cepEndereco){
        this.cepEndereco = cepEndereco;
    }    
}
