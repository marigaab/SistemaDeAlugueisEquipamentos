/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author hidde
 */
public class ModeloEquipamento {
    private int idEquipamento;
    private String nomeEquipamento;
    private String modeloEquipamento;
    private String marcaEquipamento;
    private String tipoEquipamento;
    private String entradaEquipamento;
    private String  statusEquipamento;
    private int   quantidadeEquipamento;
    private int totalDisponiveis;
    private int totalOcupados;
    private int totalTroca;

   
    
    //construtores
    
    public ModeloEquipamento(){
    }
    
    //construtor para quando não se tem um id, ou seja, está criando uma entrada nova
    public ModeloEquipamento (String nomeEquipamento, String modeloEquipamento, String marcaEquipamento, String tipoEquipamento, String entradaEquipamento, String statusEquipamento, int quantidadeEquipamento, int totalDisponiveis, int totalOcupados, int totalTroca ){
        this.nomeEquipamento = nomeEquipamento;
        this.modeloEquipamento = modeloEquipamento;
        this.marcaEquipamento = marcaEquipamento;
        this.tipoEquipamento = tipoEquipamento;
        this.entradaEquipamento = entradaEquipamento;
        this.statusEquipamento = statusEquipamento;
        this.quantidadeEquipamento = quantidadeEquipamento;
        this.totalDisponiveis = totalDisponiveis;
        this.totalOcupados = totalOcupados;
        this.totalTroca = totalTroca;
  
		
    }
    
    //construtor para quando já se tem um id e necessita modificar-lo
    public ModeloEquipamento(int idEquipamento, String nomeEquipamento, String modeloEquipamento, String marcaEquipamento, String tipoEquipamento, String entradaEquipamento,  String statusEquipamento, int quantidadeEquipamento, int totalDisponiveis, int totalOcupados, int totalTroca ){
        this.idEquipamento = idEquipamento; 
        this.nomeEquipamento = nomeEquipamento;
        this.modeloEquipamento = modeloEquipamento;
        this.marcaEquipamento = marcaEquipamento;
        this.tipoEquipamento = tipoEquipamento;
        this.entradaEquipamento = entradaEquipamento;
        this.statusEquipamento = statusEquipamento;
        this.quantidadeEquipamento = quantidadeEquipamento;
        this.totalDisponiveis = totalDisponiveis;
        this.totalOcupados = totalOcupados;
        this.totalTroca = totalTroca;
    }
    
    //metodos get
    public int getIdEquipamento(){
        return idEquipamento;
    }
    
    public String getNomeEquipamento(){
        return nomeEquipamento;
    }
    
    public String getModeloEquipamento(){
        return modeloEquipamento;
    }
    
    public String getMarcaEquipamento(){
        return marcaEquipamento;
    }
    
    public String getTipoEquipamento(){
        return tipoEquipamento;
    }
    
    public String getEntradaEquipamento(){
        return entradaEquipamento;
    }
    
    //metodos set
    public void setIdEquipamento(int idEquipamento){
        this.idEquipamento = idEquipamento;
    }
    
    public void setNomeEquipamento(String nomeEquipamento){
        this.nomeEquipamento = nomeEquipamento;
    }
    
    public void setModeloEquipamento(String modeloEquipamento){
        this.modeloEquipamento = modeloEquipamento;
    }

    public void setMarcaEquipamento(String marcaEquipamento){
        this.marcaEquipamento = marcaEquipamento;
    }
    
    public void setTipoEquipamento(String tipoEquipamento){
        this.tipoEquipamento = tipoEquipamento;
    }  
    
    public void setEntradaEquipamento(String entradaEquipamento){
        this.entradaEquipamento = entradaEquipamento;
    }
    
     public String getStatusEquipamento() {
        return statusEquipamento;
    }

    public void setStatusEquipamento(String statusEquipamento) {
        this.statusEquipamento = statusEquipamento;
    }

    public int getQuantidadeEquipamento() {
        return quantidadeEquipamento;
    }

    public void setQuantidadeEquipamento(int quantidadeEquipamento) {
        this.quantidadeEquipamento = quantidadeEquipamento;
    }
    public int getTotalDisponiveis() {
        return totalDisponiveis;
    }

    public void setTotalDisponiveis(int totalDisponiveis) {
        this.totalDisponiveis = totalDisponiveis;
    }

    public int getTotalOcupados() {
        return totalOcupados;
    }

    public void setTotalOcupados(int totalOcupados) {
        this.totalOcupados = totalOcupados;
    }

    public int getTotalTroca() {
        return totalTroca;
    }

    public void setTotalTroca(int totalTroca) {
        this.totalTroca = totalTroca;
    }
}