/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author hidde
 */
public class ModeloEquipamentoOS {
    private int idEquipamento;
    private int idOS;
    
    public ModeloEquipamentoOS(){
    }
    
    public ModeloEquipamentoOS(int idEquipamento, int idOS){
        this.idEquipamento = idEquipamento;
        this.idOS = idOS;
    }
    
    public int getIdEquipamento(){
        return idEquipamento;
    }
    
    public int getIdOS(){
        return idOS;
    }
    
    public void setIdEquipamento(int idEquipamento){
        this.idEquipamento = idEquipamento;
    }
    
    public void setIdOS(int idOS){
        this.idOS = idOS;
    }
}
