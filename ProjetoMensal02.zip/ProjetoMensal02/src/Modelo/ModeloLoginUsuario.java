/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author maria
 */

public class ModeloLoginUsuario {
    private int idCadUser;
    private String nome;
    private String email;
    private String senha;

    // Construtor
    public ModeloLoginUsuario() {
    }

    // Para buscar pelo nome
    public ModeloLoginUsuario(String nome) {
        this.nome = nome;
    }

    // Para cadastro
    public ModeloLoginUsuario (int idCadUser, String nome) {
        this.idCadUser = idCadUser;
        this.nome = nome;
    }

public int getIdCadUser() {
        return idCadUser;
    }

    public void setIdCadUser(int idCadUser) {
        this.idCadUser = idCadUser;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}