/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author hidde
 */
public class ModeloMotorista {
    private int     idMotorista;
    private String  nomeMotorista;
    private String  cnhMotorista;
    private String  tipoCnhMotorista;
    private String  celularMotorista;
    private String  statusMotorista;
    private int numCadastrosMotoristas;
    private int somaCadastrosMotoristas;
    private int totalMotoristasDisponiveis;
    private int totalMotoristasEmRota;
    
    //construtores
    
    public ModeloMotorista(){
    }
    
    //construtor para quando não se tem um id, ou seja, está criando um Motorista novo
    public ModeloMotorista (String nomeMotorista, String cnhMotorista, String tipoCnhMotorista, String celularMotorista, String statusMotorista){
        this.nomeMotorista = nomeMotorista;
        this.cnhMotorista = cnhMotorista;
        this.tipoCnhMotorista = tipoCnhMotorista;
        this.celularMotorista = celularMotorista;
        this.statusMotorista = statusMotorista;
    }
    
    //construtor para quando já se tem um id e necessita modificar-lo
    public ModeloMotorista(int idMotorista, String nomeMotorista, String cnhMotorista, String tipoCnhMotorista, String celularMotorista, String statusMotorista){
        this.idMotorista = idMotorista;
        this.nomeMotorista = nomeMotorista;
        this.cnhMotorista = cnhMotorista;
        this.tipoCnhMotorista = tipoCnhMotorista;
        this.celularMotorista = celularMotorista;
        this.statusMotorista = statusMotorista;  
    }
    
    public ModeloMotorista  (int numCadastrosMotoristas, int somaCadastrosMotoristas, int totalMotoristasDisponiveis, int totalMotoristasEmRota) {
        this.numCadastrosMotoristas = numCadastrosMotoristas;
        this.somaCadastrosMotoristas = somaCadastrosMotoristas; 
        this.totalMotoristasDisponiveis = totalMotoristasDisponiveis;
        this.totalMotoristasEmRota = totalMotoristasEmRota;
  
    } 
    
    //metodos get
    public int getIdMotorista(){
        return idMotorista;
    }
    
    public String getNomeMotorista(){
        return nomeMotorista;
    }
    
    public String getCnhMotorista(){
        return cnhMotorista;
    }
    
    public String getTipoCnhMotorista(){
        return tipoCnhMotorista;
    }
    
    public String getCelularMotorista(){
        return celularMotorista;
    }
   
    public String getStatusMotorista(){
        return statusMotorista;
    }
    
    //metodos set
    public void setIdMotorista(int idMotorista){
        this.idMotorista = idMotorista;
    }
    
    public void setNomeMotorista(String nomeMotorista){
        this.nomeMotorista = nomeMotorista;
    }
    
    public void setCnhMotorista(String cnhMotorista){
        this.cnhMotorista = cnhMotorista;
    }

    public void setTipoCnhMotorista(String tipoCnhMotorista){
        this.tipoCnhMotorista = tipoCnhMotorista;
    }
    
    public void setCelularMotorista(String celularMotorista){
        this.celularMotorista = celularMotorista;
    }
    
    public void setStatusMotorista(String statusMotorista){
        this.statusMotorista = statusMotorista;
    }
    
    @Override
    public String toString() {
        return nomeMotorista + " (ID: " + idMotorista + ")";
    }
    
      public int getTotalCadastrosMotoristas() {
        return numCadastrosMotoristas;
    }

    public void setTotalCadastrosMotoristas(int numCadastrosMotoristas) {
        this.numCadastrosMotoristas = numCadastrosMotoristas;
    }

    public int getSomaCadastrosMotoristas() {
        return somaCadastrosMotoristas;
    }

    public void setSomaCadastrosMotoristas(int somaCadastrosMotoristas) {
    this.somaCadastrosMotoristas = somaCadastrosMotoristas;
}
    
     public int getTotalMotoristasDisponiveis() {
        return totalMotoristasDisponiveis;
    }

    public void setTotalMotoristasDisponiveis(int totalMotoristasDisponiveis) {
        this.totalMotoristasDisponiveis = totalMotoristasDisponiveis;
    }

    public int getTotalMotoristasEmRota() {
        return totalMotoristasEmRota;
    }

    public void setTotalMotoristasEmRota(int totalMotoristasEmRota) {
        this.totalMotoristasEmRota = totalMotoristasEmRota;
    }
}
