/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author hidde
 */
public class ModeloOS {
    private int idOS;
    private String dataOS;
    private String valorOS;
    private int clienteOS;
    private Integer enderecoOS;
    private String descricaoOS;
    private int motoristaOS;
    private int veiculoOS;
    private int numOS;
    private int somaOS;
    private int totalConcluidas;
    private int totalPendentes;
     private int totalSemanal;
    private int totalMensal;
    private int totalAnual;
    private float faturamentoSemanal;
    private float faturamentoMensal;
    private float faturamentoAnual;
    private String endereco1;
    private int qtdEndereco1;
    private String endereco2;
    private int qtdEndereco2;
    private String endereco3;
    private int qtdEndereco3;
  
    
    public ModeloOS(){
    }
    
    public ModeloOS (String dataOS, String valorOS, Integer enderecoOS, int clienteOS,
                     String descricaoOS, int motoristaOS, int veiculoOS, int totalSemanal, int totalMensal, int totalAnual ){
        this.dataOS = dataOS;
        this.valorOS = valorOS;
        this.enderecoOS = enderecoOS;
        this.clienteOS = clienteOS;
        this.descricaoOS = descricaoOS;
        this.motoristaOS = motoristaOS;
        this.veiculoOS = veiculoOS;
        this.totalSemanal = totalSemanal;
        this.totalMensal  = totalMensal;
        this.totalAnual = totalMensal;
    }
    
    public ModeloOS (int idOS, String dataOS, String valorOS, Integer enderecoOS, int clienteOS,
                     String descricaoOS, int motoristaOS, int veiculoOS){
        this.idOS = idOS;
        this.dataOS = dataOS;
        this.valorOS = valorOS;
        this.enderecoOS = enderecoOS;
        this.clienteOS = clienteOS;
        this.descricaoOS = descricaoOS;
        this.motoristaOS = motoristaOS;
        this.veiculoOS = veiculoOS;
    
    }
    
    public ModeloOS  (int numOS, int somaOS, int totalConcluidas, int totalPendentes,  int totalSemanal, int totalMensal,
            int totalAnual, float faturamentoSemanal, float faturamentoMensal,  float faturamentoAnual,
            String endereco1, int qtdEndereco1, String endereco2, int qtdEndereco2, String endereco3,  int qtdEndereco3 ) {
      
        this.numOS = numOS;
        this.somaOS = somaOS; 
        this.totalConcluidas =  totalConcluidas;
        this.totalPendentes = totalPendentes;
        this.totalSemanal = totalSemanal;
        this.totalMensal  = totalMensal;
        this.totalAnual = totalMensal;
        this.faturamentoSemanal = faturamentoSemanal;
        this.faturamentoMensal = faturamentoMensal;
        this.faturamentoAnual = faturamentoMensal;
        this.endereco1 = endereco1;
        this. qtdEndereco1 =  qtdEndereco1;
       this.endereco2 =  endereco2;
       this. qtdEndereco2 = qtdEndereco2;
       this. endereco3 = endereco3;
       this. qtdEndereco3 = qtdEndereco3;

  
    } 
    
    public int getIdOS(){
        return idOS;
    }
    
    public String getDataOS(){
        return dataOS;
    }
    
    public String getValorOS(){
        return valorOS;
    }
    
    public int getEnderecoOS(){
        return enderecoOS;
    }
    
    public String getDescricaoOS(){
        return descricaoOS;
    }
    
    public int getMotoristaOS(){
        return motoristaOS;
    }
    
    public int getVeiculoOS(){
        return veiculoOS;
    }
    
    public int getClienteOS(){
        return clienteOS;
    }
    
    public void setIdOS (int idOS){
        this.idOS = idOS;
    }
    
    public void setDataOS (String dataOS){
        this.dataOS = dataOS;
    }
    
    public void setValorOS(String valorOS){
        this.valorOS = valorOS;
    }
    
    public void setEnderecoOS (Integer enderecoOS){
        this.enderecoOS = enderecoOS;
    }
    
    public void setDescricaoOS(String descricaoOS){
        this.descricaoOS = descricaoOS;
    }
    
    public void setMotoristaOS(int motoristaOS){
        this.motoristaOS = motoristaOS;
    }
    
    public void setVeivuloOS(int veiculoOS){
        this.veiculoOS = veiculoOS;
    }
    
    public void setClineteOS(int clienteOS){
        this.clienteOS = clienteOS;
    }
    
      public int getTotalOS() {
        return numOS;
    }

    public void setTotalOS(int numOS) {
        this.numOS = numOS;
    }

    public int getSomaOS() {
        return somaOS;
    }

    public void setSomaOS(int somaOS) {
    this.somaOS = somaOS;
}
public int getTotalConcluidas() {
        return totalConcluidas;
    }

    public void setTotalConcluidas(int totalConcluidas) {
        this.totalConcluidas = totalConcluidas;
    }

    public int getTotalPendentes() {
        return totalPendentes;
    }

    public void setTotalPendentes(int totalPendentes) {
        this.totalPendentes = totalPendentes;
    }   
     public int getTotalSemanal() {
        return totalSemanal;
    }

    public void setTotalSemanal(int totalSemanal) {
        this.totalSemanal = totalSemanal;
    }

    public int getTotalMensal() {
        return totalMensal;
    }

    public void setTotalMensal(int totalMensal) {
        this.totalMensal = totalMensal;
    }

    public int getTotalAnual() {
        return totalAnual;
    }

    public void setTotalAnual(int totalAnual) {
        this.totalAnual = totalAnual;
    }
     public float getFaturamentoSemanal() {
        return faturamentoSemanal;
    }

    public void setFaturamentoSemanal(float faturamentoSemanal) {
        this.faturamentoSemanal = faturamentoSemanal;
    }

    public float getFaturamentoMensal() {
        return faturamentoMensal;
    }

    public void setFaturamentoMensal(float faturamentoMensal) {
        this.faturamentoMensal = faturamentoMensal;
    }

    public float getFaturamentoAnual() {
        return faturamentoAnual;
    }

    public void setFaturamentoAnual(float faturamentoAnual) {
        this.faturamentoAnual = faturamentoAnual;
    }
 public String getEndereco1() {
        return endereco1;
    }

    public void setEndereco1(String endereco1) {
        this.endereco1 = endereco1;
    }

    public int getQtdEndereco1() {
        return qtdEndereco1;
    }

    public void setQtdEndereco1(int qtdEndereco1) {
        this.qtdEndereco1 = qtdEndereco1;
    }

    public String getEndereco2() {
        return endereco2;
    }

    public void setEndereco2(String endereco2) {
        this.endereco2 = endereco2;
    }

    public int getQtdEndereco2() {
        return qtdEndereco2;
    }

    public void setQtdEndereco2(int qtdEndereco2) {
        this.qtdEndereco2 = qtdEndereco2;
    }

    public String getEndereco3() {
        return endereco3;
    }

    public void setEndereco3(String endereco3) {
        this.endereco3 = endereco3;
    }

    public int getQtdEndereco3() {
        return qtdEndereco3;
    }

    public void setQtdEndereco3(int qtdEndereco3) {
        this.qtdEndereco3 = qtdEndereco3;
    }
}
