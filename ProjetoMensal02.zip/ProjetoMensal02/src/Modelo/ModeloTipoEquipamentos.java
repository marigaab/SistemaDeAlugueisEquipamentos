/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author hidde
 */
public class ModeloTipoEquipamentos {
    private int idTipoEquipamento;
    private String nomeTipoEquipamento;

    public ModeloTipoEquipamentos(){
    }
    
    public ModeloTipoEquipamentos(String nomeTipoEquipamento){
        this.nomeTipoEquipamento = nomeTipoEquipamento;
    }
    
    public ModeloTipoEquipamentos(int idTipoEquipamento, String nomeTipoEquipamento){
        this.idTipoEquipamento = idTipoEquipamento;
        this.nomeTipoEquipamento = nomeTipoEquipamento;
    }
    
    public int getIdTipoEquipamento(){
        return idTipoEquipamento;
    }
    
    public String getNomeTipoEquipamento(){
        return nomeTipoEquipamento;
    }
    
    public void setIdTipoEquipamento(int idTipoEquipamento){
        this.idTipoEquipamento = idTipoEquipamento;
    }
    
    public void setNomeTipoEquipamento(String nomeTipoEquipamento){
        this.nomeTipoEquipamento = nomeTipoEquipamento;
    }
}