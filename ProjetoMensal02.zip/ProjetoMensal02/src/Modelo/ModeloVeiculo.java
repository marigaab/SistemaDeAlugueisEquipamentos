/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author hidde
 */
public class ModeloVeiculo {
    private int     idVeiculo;
    private String  nomeVeiculo;
    private int     anoVeiculo;
    private String  marcaVeiculo;
    private String  placaVeiculo;
    private String  chassiVeiculo;
    private String  patrimonioVeiculo;
    private String  observacaoVeiculo;
    private int numCadastrosVeiculos;
    private int somaCadastrosVeiculos;

    
    //construtores
    
    public ModeloVeiculo(){
    }
    
    //construtor para quando não se tem um id, ou seja, está criando um Veiculo novo
    public ModeloVeiculo (String nomeVeiculo, String cnhVeiculo, int anoVeiculo, String marcaVeiculo, String placaVeiculo, String chassiVeiculo, String patrimonioVeiculo, String observacaoVeiculo){
        this.nomeVeiculo = nomeVeiculo;
        this.anoVeiculo = anoVeiculo;
        this.marcaVeiculo = marcaVeiculo;
        this.placaVeiculo = placaVeiculo;
        this.chassiVeiculo = chassiVeiculo;
        this.patrimonioVeiculo = patrimonioVeiculo;
        this.observacaoVeiculo = observacaoVeiculo;
    }
    
    //construtor para quando já se tem um id e necessita modificar-lo
    public ModeloVeiculo(int idVeiculo, String nomeVeiculo, String cnhVeiculo, int anoVeiculo, String marcaVeiculo, String placaVeiculo, String chassiVeiculo, String patrimonioVeiculo, String observacaoVeiculo){
        this.idVeiculo = idVeiculo;
        this.nomeVeiculo = nomeVeiculo;
        this.anoVeiculo = anoVeiculo;
        this.marcaVeiculo = marcaVeiculo;
        this.placaVeiculo = placaVeiculo;
        this.chassiVeiculo = chassiVeiculo;
        this.patrimonioVeiculo = patrimonioVeiculo;
        this.observacaoVeiculo = observacaoVeiculo;
      
    }
    
     public ModeloVeiculo  (int numCadastrosVeiculos, int somaCadastrosVeiculos) {
        this.numCadastrosVeiculos = numCadastrosVeiculos;
        this.somaCadastrosVeiculos = somaCadastrosVeiculos; 
  
    } 
    
    //metodos get
    public int getIdVeiculo(){
        return idVeiculo;
    }
    
    public String getNomeVeiculo(){
        return nomeVeiculo;
    }
    
    public int getAnoVeiculo(){
        return anoVeiculo;
    }
    
    public String getMarcaVeiculo(){
        return marcaVeiculo;
    }
   
    public String getPlacaVeiculo(){
        return placaVeiculo;
    }
    
    public String getChassiVeiculo(){
        return chassiVeiculo;
    }
    
    public String getPatrimonioVeiculo(){
        return patrimonioVeiculo;
    }

    public String getObservacaoVeiculo(){
        return observacaoVeiculo;
    }    
    
    //metodos set
    public void setIdVeiculo(int idVeiculo){
        this.idVeiculo = idVeiculo;
    }
    
    public void setNomeVeiculo(String nomeVeiculo){
        this.nomeVeiculo = nomeVeiculo;
    }

    public void setAnoVeiculo(int anoVeiculo){
        this.anoVeiculo = anoVeiculo;
    }
    
    public void setMarcaVeiculo(String marcaVeiculo){
        this.marcaVeiculo = marcaVeiculo;
    }
    
    public void setPlacaVeiculo(String placaVeiculo){
        this.placaVeiculo = placaVeiculo;
    }
    
    public void setChassiVeiculo(String chassiVeiculo){
        this.chassiVeiculo = chassiVeiculo;
    }
    
    public void setPatrimonioVeiculo(String patrimonioVeiculo){
        this.patrimonioVeiculo = patrimonioVeiculo;
    }
    
    public void setObservacaoVeiculo(String observacaoVeiculo){
        this.observacaoVeiculo = observacaoVeiculo;
    }
    
    @Override
    public String toString() {
        return nomeVeiculo + " (ID: " + idVeiculo + ")";
    }
    
    
    
     public int getTotalCadastrosVeiculos() {
        return numCadastrosVeiculos;
    }

    public void setTotalCadastrosVeiculos(int numCadastrosVeiculos) {
        this.numCadastrosVeiculos = numCadastrosVeiculos;
    }

    public int getSomaCadastrosVeiculos() {
        return somaCadastrosVeiculos;
    }

    public void setSomaCadastrosVeiculos(int somaCadastrosVeiculos) {
    this.somaCadastrosVeiculos = somaCadastrosVeiculos;
}
  
}